from app.database import export_data_to_postgres

if __name__ == '__main__':
    export_data_to_postgres()
